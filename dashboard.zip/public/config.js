window.APP_CONFIG = {
  AUTH_API_URL: 'http://localhost:3001',
  API_URL: '/api',
  CLIENT_ID: 'cli-web-pnc',
  AUTH_REALM: 'intranet',
  FALLBACK_TOKEN: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c',
  SERVICE_CLIENT_SECRET:'07c7b9c9-ee4e-4d22-a978-718d8727ebd4',
  SERVICE_CLIENT_ID: 'cli-ser-gpf'

};